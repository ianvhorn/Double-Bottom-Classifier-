# -*- coding: utf-8 -*-
"""
Created on Mon Mar 25 20:07:44 2024

@author: ianva
"""
import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt
import cv2



CWD = os.path.dirname(os.getcwd())
SAVE_PATH = os.path.join(CWD, 'DBimages')
SAVE_PATH2 = os.path.join(CWD, 'LOOK_TAG')
TRU_DIR = os.path.join(CWD, r'DB_sections')
TRU_PATH = os.path.join(CWD, r'DB_sections\SPY_TRU.csv')
df = pd.read_csv(os.path.join(CWD,"SPY_93_24.csv"), skiprows=[0], header = None)
lent = df.shape[0]
df = df.iloc[0:lent]
df_plot = df.iloc[0:lent,[0,2]]


def click_event(event, x, y, flags, params): 
    global Xcoord
    global Ycoord
    # checking for left mouse clicks 
    if event == cv2.EVENT_LBUTTONDOWN: 
       Xcoord = x
       Ycoord = y


def annotate():
    label = os.path.join(TRU_PATH,'SPY_TRU.csv')
    
    #if the file had data, start where you left off, if its empty start at 0
    try:
        df_startval = pd.read_csv(TRU_PATH)
        a = df_startval.iloc[-1,1]
    except pd.errors.EmptyDataError:
        a = 0
    
   
   
    
    end = 0
    while end < lent: # for all data in the .csv
        peakType = 0;
        dataPointA = -1;
        dataPointB = -1;
    
        # Define start and end points of the display
        b = a+180
        end += 60
        
        df_sect = np.array(df_plot.iloc[a:b]) #Copy the needed section from the full dataframe
        
        plt.figure(figsize=(15,6))# make the figure wider to more easily see data
        
        # Get rid of padding on x axis (this makes it easier to go from pixels to data values)
        ax = plt.gca();
        ax.set_xlim(0.0, 179);

        #Create the plot and save is as a unique image
        plt.plot(range(0,180),df_sect[:,1]) 
        num = a//60
        temp_path = os.path.join(SAVE_PATH,str(num))
        plt.savefig(temp_path) # Save the matplot plot as a png
        
        # set up some info about the image size
        img = cv2.imread(os.path.join(temp_path+".png"))#Read in the png of the matplot graph
        imgHeight = img.shape[0]
        graphLength = (img.shape[1]-(img.shape[1]-972) - 135) #the length, in pixels, of the x axis
        imgLength = graphLength//3 # 1/3 of the graph, the first and last third are not recorded



        # Show lines on image for region that will be recorded
        cv2.line(img,(imgLength+137,0),(imgLength+137,imgHeight),(255,0,0),1)
        cv2.line(img,((imgLength*2)+138,0),((imgLength*2)+138,imgHeight),(255,0,0),1)

        cv2.putText(img, "DATA STARTS AT: "+ str(a) + " DAYS FROM JAN 31 1993",fontFace=cv2.FONT_HERSHEY_COMPLEX,fontScale=.5,
                    org=(10,30),color = (0,0,0),thickness=1)
        cv2.imshow("REGION", img) #Display the image
        
        # Code for the UI
        k = 0
        peakType = 0
        while(k != ord('q')): # While the image is shown and q is not pressed
            cv2.setMouseCallback('REGION', click_event) #Record the pixel coords of a click
            if k == ord('w'): # If w is pressed
                
                #Record the click coords as the start point and draw a line there
                XcoordA = Xcoord
                YcoordA = Ycoord
                cv2.line(img,(XcoordA,YcoordA - 10),(XcoordA,YcoordA+10),(0,255,0),2)
                cv2.imshow("REGION", img)
                peakType = 1
                dataPointA = (((XcoordA-135)/graphLength)*180)//1
            elif k == ord('e'): # same for end point
                XcoordB = Xcoord
                YcoordB = Ycoord
                cv2.line(img,(XcoordB,YcoordB - 10),(XcoordB,YcoordB+10),(0,0,255),2)
                cv2.imshow("REGION", img)
                peakType = 1
                dataPointB = (((XcoordB-135)/graphLength)*180)//1
                
            k =  cv2.waitKey(0) # always set K equal to whatever key is pressed
        
        # Convert pixel coords on the image to a datapoint in the csv
        
        
        
        #Close and clear the window
        cv2.destroyAllWindows() 
        plt.clf()
        os.remove(os.path.join(temp_path+".png")) #no need to keep images, delete them
        
        if a ==0:
            df_out = pd.DataFrame({"Start":a,
                    "End":[b],
                    "DBstart":[dataPointA],
                    "DBend":[dataPointB],
                    "Class":[peakType]})
            if peakType == 1:
                df_out.to_csv(os.path.join(TRU_DIR, "SPY_TRU_onlyDB.csv"), index=False)
            elif peakType == 0:
                df_out.to_csv(os.path.join(TRU_DIR, "SPY_TRU_neg.csv"), index=False)
        else:
            data_temp = pd.DataFrame({"Start":[a],
                    "End":[b],
                    "DBstart":[dataPointA],
                    "DBend":[dataPointB],
                    "Class":[peakType]})
            df_out = pd.read_csv(TRU_PATH)
            df_out = pd.concat([df_out,data_temp], ignore_index=1)
            
            if peakType == 1:
                try:
                    df_out_tru = pd.read_csv(os.path.join(TRU_DIR, 'SPY_TRU_onlyDB.csv'))
                    df_out_tru = pd.concat([df_out_tru,data_temp], ignore_index=1)
                    df_out_tru.to_csv(os.path.join(TRU_DIR, 'SPY_TRU_onlyDB.csv'), index=False)
                except pd.errors.EmptyDataError:
                    df_out.to_csv(os.path.join(TRU_DIR, 'SPY_TRU_onlyDB.csv'), index=False)
                
            elif peakType == 0:
                try:
                    df_out_neg = pd.read_csv(os.path.join(TRU_DIR, "SPY_TRU_onlyDB.csv"))
                    df_out_neg = pd.concat([df_out_neg,data_temp], ignore_index=1)
                    df_out_neg.to_csv(os.path.join(TRU_DIR, "SPY_TRU_neg.csv"), index=False)
                except pd.errors.EmptyDataError:
                    df_out.to_csv(os.path.join(TRU_DIR, 'SPY_TRU_onlyDB.csv'), index=False)
    

        df_out.to_csv(TRU_PATH, index=False)
        
        '''
        If the section had a double bottom, shift the whole section out. Now that section
        is the first third of the next image displayed.
        
        If it did not have a DB, only shift the earlier half out. This way if there was a
        DB on the edge of the boundry it will still be recorded 
        '''
        
        if peakType == 1:
            a += 60
        else:
            a += 30
            
            
def visualize (tru_path = r"C:\Users\ianva\TechnicalAnalysisCNN\TRAIN\SPY_TRU.csv"):
    df_tru = pd.read_csv(tru_path)
    count = 0
    end = 0
    print(df_tru.shape[0])
    while count < df_tru.shape[0]:
        start  = df_tru.iloc[count,0]
        end = df_tru.iloc[count,1]
        df_sect = np.array(df_plot.iloc[start:end])
        bar_start = df_tru.iloc[count,2]
        bar_end = df_tru.iloc[count,3]
        
        
        plt.figure(figsize=(15,6))# make the figure wider to more easily see data
        
        # Get rid of padding on x axis (this makes it easier to go from pixels to data values)
        ax = plt.gca();
        ax.set_xlim(0.0, 179);
        
        
        plt.plot(range(0,180),df_sect[:,1]) 
        num = end//60
        temp_path = os.path.join(SAVE_PATH2,str(num))
        plt.savefig(temp_path) # Save the matplot plot as a png
        
        img = cv2.imread(os.path.join(temp_path+".png"))#Read in the png of the matplot graph
        imgHeight = img.shape[0]
        graphLength = (img.shape[1]-(img.shape[1]-972) - 135) #the length, in pixels, of the x axis
        imgLength = graphLength//3 # 1/3 of the graph, the first and last third are not recorded



        # Show lines on image for region that will be recorded
        cv2.line(img,(imgLength+137,0),(imgLength+137,imgHeight),(255,0,0),1)
        cv2.line(img,((imgLength*2)+138,0),((imgLength*2)+138,imgHeight),(255,0,0),1)
        
        x1 = int(((bar_start/180)*graphLength)+135)
        x2 = int(((bar_end/180)*graphLength)+135)
        print(bar_start)
        print(x1)
        print("    ")
        print(bar_end)
        print(x2)
        print("--------------------------")
        
        cv2.line(img,(x1,0),(x1,imgHeight),(0,255,0),3)
        cv2.line(img,(x2,0),(x2,imgHeight),(0,0,255),3)
        
        cv2.imshow("region", img)
        cv2.waitKey(0)
        count += 1
        
        
        
annotate()  
#visualize()














