# -*- coding: utf-8 -*-
"""
Created on Sat Apr 27 15:02:22 2024

@author: ianva
"""
import numpy as np
import pandas as pd
import random
import os
import matplotlib.pyplot as plt
import cv2
from tensorflow import keras #api for tensorflow
from keras.models import Sequential
from keras.optimizers import Adam
from keras.layers import Convolution1D, Dense, MaxPool1D, Dropout, BatchNormalization
from sklearn import metrics

import Model2 as mod


while(1):
    x = input("Press 1 to evaluate the model from the report. Press 0 to train a model on our dataset\n")
    
    if(x =='1'):
        CWD = os.path.dirname(os.getcwd())
        allldata=mod.csv_annotations()
        data = allldata[0]
        labels = allldata[1]
        model = keras.models.load_model(os.path.join(CWD,'Models','Final','savedModel.keras'))#load model
        mod.evaluate_model(data, labels, model)
    elif(x=='0'):
        mod.generate_model()
    else:
        print("Invalid input, press 1 or 0")
