# -*- coding: utf-8 -*-
"""
Created on Mon Aug 21 14:17:45 2023

@author: mrbrady1
"""
import random
import numpy as np
import pandas as pd
import cv2
import os
import matplotlib.pyplot as plt
from tensorflow import keras #api for tensorflow
from keras.models import Sequential
from keras.optimizers import Adam
from keras.layers import Convolution1D, Dense, MaxPool1D, Dropout, BatchNormalization
from sklearn import metrics


CWD = os.path.dirname(os.getcwd())
RAW_DATA_DIR = os.path.join(CWD,'RAW_DATA')
ROI_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Data')
IMG_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Images')
ANNOTATION_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Labels')


def plot_inference(save_path, line_df, truth_locations = [], truth_classes = [], vlines = [], fig_width = 1):
    colors = ['r', 'g', 'b', 'k']
    line = pd.DataFrame(line_df).to_numpy()
    plt.plot(line[:,0], line[:,1])
    #ax.set_ylim([-3, 5])
    #print(len(truth_classes), len(truth_locations), len(vlines))
    for point, classID, vline in zip(truth_locations, truth_classes, vlines):
        color = np.random.rand(3,)
        #print(point)
        #print(vline)
        plt.scatter(point[0], point[1]/10, color = colors[classID])
        
        plt.axvline(x = vline[0], color = color,linewidth = .5)
        plt.axvline(x = vline[1], color = color, linewidth = .5)
    plt.rcParams["figure.figsize"] = (fig_width,5)
    plt.savefig(save_path)
    plt.close('all')


def csv_annotations(ROI_DIR = ROI_DIR, ANNOTATION_DIR = ANNOTATION_DIR):
    length = len(os.listdir(ANNOTATION_DIR))/20
    count = 0
    count2 = 0
    bar = '[....................]'
    full = '====================='
   
    data = []
    annotations = []
    
    for file in os.listdir(ROI_DIR):
        df = pd.read_csv(os.path.join(ROI_DIR,file), skiprows=[0], header = None)

        if len(df.index) == 64:
            for txt in os.listdir(ANNOTATION_DIR):
                
                if txt.replace('txt', 'csv') == file:
                    count += 1
                    if count % length == 0:
                        count2 += 1
                        progress = '['+full[0:count2]+bar[count2:] 
                        print(progress)
                        
                        
                        
                        
                    with open(os.path.join(ANNOTATION_DIR,txt), 'r') as LabelFile:
                        data.append(df[1].to_numpy())
                        annotations.append(LabelFile.read())
    data = np.array(data)
    annotations = np.array(annotations)
    return data, annotations


def annotate(ROI_dir, label_dir, image_dir, regenerate = False):
    if regenerate:
        for file in os.listdir(ROI_dir):
            print(file)
            df = pd.read_csv(os.path.join(ROI_dir, file), names=['Time', 'Volt'], skiprows=[0])
            plot_inference(os.path.join(image_dir, file.replace('.csv', '.png')), df, fig_width=1)
        
    for image in os.listdir(image_dir):
        peakType = 2
    
        #Checks if coressponding label exists
        label = os.path.join(label_dir, image.replace('.png', '.txt'))
        if not os.path.isfile(label):
            
            #Read in an load the image
            print(os.path.join(image_dir, image))
            img = cv2.imread(os.path.join(image_dir, image))
            
            h, w, l = img.shape
            
            cv2.namedWindow("RAW DATA", cv2.WINDOW_AUTOSIZE)
            #print(w, h)
            w = int(w / 2.5)
            h = int(h / 2.5)
            #print(w, h)
            #img = cv2.resize(img, (w, h))
            
            cv2.imshow("RAW DATA", img)
    
            #Lets the user select the peak type and press "q" to quit
            k = 0
            while(k != ord('q')):
                if k == ord('w'):
                    peakType = 0
                elif k == ord('e'):
                    peakType = 1
                elif k == ord('r'):
                    peakType = 2
                
                k = cv2.waitKey(1) & 0xFF
    
            with open(label, 'w') as writeTo:
                writeTo.write("{}".format(peakType) + "\n")
            cv2.destroyAllWindows()


def find_ROIs(input_file, output_dir, resample_duration = 1, PEAK_SEPERATION_VOLTAGE = 0.5, NEAR_ZERO_THRESHOLD = 0.1):
    current_peak = False
    count = 0
    box_bound = 0
    #print(input_file)
    df = pd.read_csv(input_file, names=['Time', 'Volt'], skiprows=[0])
    df['Time'] = pd.to_datetime(df['Time'], unit = 's')
   
    new_range = pd.date_range(df.Time[0], df.Time.values[-1], freq = 's')
    resampled_df = df.set_index('Time').reindex(new_range).interpolate().reset_index()

    rd_string = str(resample_duration) + 'S'

    final_df = resampled_df.set_index('index').resample(rd_string).mean()
    final_df.index = final_df.index.astype('int64')/(1000000000 * resample_duration)
    final_df.index = final_df.index.astype('int64')
    upper_bound = df.shape[0]

    for index, point in df.iterrows():
        if point['Volt'] > 0.7 and not current_peak:
            current_peak = True
            count += 1
           
            filename = os.path.basename(input_file).replace('.csv', "Region" + str(count) + ".csv")
            box_bound = index + 64
           
            if box_bound > upper_bound:
                #print(upper_bound, 'too small for region extending to', box_bound)
                addition_frame = pd.DataFrame(np.zeros((box_bound - upper_bound, 1)), columns = ['Volt'])
                df = pd.concat([df, addition_frame], ignore_index=True)
               
                #print('New dataframe shape:', df.shape)
           
            df[(index):(box_bound)].to_csv(os.path.join(output_dir, filename), columns = ['Volt'])
        elif current_peak and index >= box_bound:
            current_peak = False
    return(count)





def production_model(LIST_ROI,model = r"C:\Users\ianva\ddPCR_DataProcessing\modelFile.keras" ):
    model = keras.models.load_model(model)#load model
    peak_count = 0;
    
    # NN accepts a (1,1,1) array of datatype array. Take in the multipus ROI arrays
    # of data and reformat it as a single array of arrays
    batch_size = np.size(LIST_ROI, 0)
    data = [LIST_ROI.reshape((batch_size,64,1))]
    classification = np.argmax(model.predict(data), axis = 2)
    peak_count = sum(classification)
    return peak_count





def evaluate_model(data, labels, model):
    x = data.reshape(len(data), 64, 1)
    y = np.array(labels).squeeze()

    predictions = np.argmax(np.array(model.predict(x)), axis = 2)
    acc = np.mean(predictions == y)
    m = metrics.classification_report(y, predictions, digits = 3)
    cm = metrics.confusion_matrix(y, predictions, normalize = 'true')
    print(cm)
    cm_display = metrics.ConfusionMatrixDisplay(cm, display_labels = ['Noise / Rebound', 'Single Peaks', 'Poly Peaks'])
    
    cm_display.plot()
    plt.show()
    
    return(acc, m)







def generate_model(ROI_DIR = ROI_DIR, ANNOTATION_DIR = ANNOTATION_DIR, weights = [80,0,20], lr = .000001, epochs = 500, loss = 'kullback_leibler_divergence'):
    data,labels = csv_annotations()
    x_test = []
    x_train = []
    x_val = []
    y_val = []
    y_train = []
    y_test = []
    
    for i in range(len(data)):
        select = random.choices(list(range(len(weights))), weights = weights)
        
        if select[0] == 0:
            
            x_train.append(np.float_(data[i]))
            y_train.append(np.int_(labels[i]))
            
            
        elif select[0] == 1:
            x_test.append(np.float_(data[i]))
            y_test.append(np.int_(labels[i]))
        elif select[0] == 2:
            x_val.append(np.float_(data[i]))
            y_val.append(np.int_(labels[i]))
            
            
    model = Sequential([
         Convolution1D(filters=2, kernel_size=5,  padding = 'same', name='c1d', activation = 'tanh'),
         MaxPool1D(2, name = 'mp1'),
         BatchNormalization(),
         Convolution1D(filters=4, kernel_size=5,  padding = 'same', name='c1d2', activation = 'tanh'),
         MaxPool1D(2, name = 'mp2'),
         BatchNormalization(),
         Convolution1D(filters=8, kernel_size=5,  padding = 'same', name='c1d3', activation = 'tanh'),
         MaxPool1D(2, name = 'mp3'),
         BatchNormalization(),
         Convolution1D(filters=16, kernel_size=5, padding='same', name='c1d4', activation = 'tanh'),
         MaxPool1D(2, name = 'mp4'),
         BatchNormalization(),
         Convolution1D(filters=32, kernel_size=5, padding='same', name='c1d5', activation = 'tanh'),
         MaxPool1D(2, name = 'mp5'),
         BatchNormalization(),
         Convolution1D(filters=64, kernel_size=5, padding='same', name='c1d6', activation = 'tanh'),
         MaxPool1D(2, name = 'mp6'),
         Dropout(0.5),
         BatchNormalization(),
         Dense(2, activation='softmax')
    ])
    
    data_length = len(x_train)
    x_train = np.array(x_train).reshape(data_length, 64, 1)
    y_train = np.array(y_train).reshape(data_length, 1, 1)
    
    print(x_train.shape, y_train.shape)
    
    
    model.compile(optimizer = Adam(learning_rate = lr), loss = loss)
    
    model.fit(x_train, y_train, 200, epochs = epochs)
    model.summary()
    evaluate_model(np.array(x_val), np.array(y_val), model)
    
    model.save(os.path.dirname(ROI_DIR))
            
            
        