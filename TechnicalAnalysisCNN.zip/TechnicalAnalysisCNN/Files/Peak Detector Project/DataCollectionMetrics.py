# -*- coding: utf-8 -*-
"""
Created on Wed Aug 23 13:23:18 2023

@author: ianva
"""

import os
import pandas as pd
import numpy as np
particle_sizes = [10, 63, 106]
ROOT_DIR = os.path.dirname(os.getcwd())
for p_size in particle_sizes:
   
    filename = 'Data Collection - ' + str(p_size) + 'um.xlsx'
   
    collection_file = os.path.join(ROOT_DIR, 'Counts', filename)
   
    df = pd.read_excel(collection_file, usecols='A:E', index_col=None)
   
    yolo_correct = 0
    newnet_correct = 0
    yolo_slide = 0
    newnet_slide = 0
   
   
    for index, row in df.iterrows():
        yolo_correct += np.abs(row['Yolo'] - row['Corrected'])
        newnet_correct += np.abs(row['NN'] - row['Corrected'])
       
        yolo_slide += np.abs(row['Yolo'] - row['Slide Count'])
        newnet_slide += np.abs(row['NN'] - row['Slide Count'])
   
    MAE_y_c = yolo_correct / index
    MAE_n_c = newnet_correct / index
    MAE_y_s = yolo_slide / index
    MAE_n_s = newnet_slide / index
   
    print(MAE_y_c, MAE_n_c)
    print(MAE_y_s, MAE_n_s)