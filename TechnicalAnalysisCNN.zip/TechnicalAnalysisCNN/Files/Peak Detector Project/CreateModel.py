# -*- coding: utf-8 -*-
"""
Created on Wed Aug 23 16:40:08 2023

@author: mrbrady1
"""

import functions as fn

fn.generate_model()