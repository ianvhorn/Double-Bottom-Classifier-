# -*- coding: utf-8 -*-
"""
Created on Wed Aug 23 13:55:54 2023

@author: mrbrady1
"""

import functions as fn
import os



CWD = os.path.dirname(os.getcwd())
RAW_DATA_DIR = os.path.join(CWD,'RAW_DATA')
ROI_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Data')
IMG_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Images')
ANNOTATION_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Labels')

#create_allROIs()
fn.annotate(ROI_DIR, ANNOTATION_DIR, IMG_DIR, regenerate=True)