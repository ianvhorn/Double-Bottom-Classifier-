# -*- coding: utf-8 -*-
"""
Created on Mon Mar 25 12:32:57 2024

@author: ianva
"""
"""
File to create and train a new neural net
"""
#import functions as fn
import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt
import cv2
import mplfinance as mpf

CWD = os.path.dirname(os.getcwd())
GT_DIR= os.path.join(CWD,'GTtoSort')
DATA_DIR = os.path.join(CWD, 'DataToSort')
SAVE_PATH = os.path.join(CWD, 'graphs')


for file in os.listdir(GT_DIR): #file is a file in the GT dir
    df = pd.read_csv(os.path.join(GT_DIR,file), skiprows=[0],usecols=[3], header = None)
    df1 = pd.read_csv(os.path.join(DATA_DIR,file.replace('GT','')),skiprows = [0],usecols=[0,1,2,3,4], header = None)
    dataGT = np.array(df)
    data = np.array(df1)
    
    DB =[]
    count = 0
    y = 0
    for x in dataGT:
        if x == "Double Bottom":
            DB.append(count)
            
        count = count + 1
        
    print(data)
    while y < len(DB):
        #idx = (DB[y]-1) * 72 + 2
        skip = 1
        q = 1
        while skip < (DB[y]-1):
            q = q+1
            if data[q,0]==0:
                skip = skip+1
           
        idx =q
        print(idx)
        
        #plt.plot(data[idx:idx+72,0],data[idx:idx+72,1])
        # Plotting up prices of the stock 
        i = 0
        
        while i < 72:
            close = data[i+idx,2]
            open1 = data[i+idx,1]
            high = data[i+idx,3]
            low = data[i+idx,4]
            width = .3
            width2 =.03
            if open1<close:
                plt.bar(i, close-open1, width, bottom=open1, color='blue') 
                plt.bar(i, high-close, width2, bottom=close, color='blue') 
                plt.bar(i, low-open1, width2, bottom=open1, color='blue') 
            else:
                plt.bar(i, close-open1, width, bottom=open1, color='red') 
                plt.bar(i, high-open1, width2, bottom=open1, color='red') 
                plt.bar(i, low-close, width2, bottom=close, color='red') 
                
                
                
            i = i+1
          
        
        
        plt.title(str(DB[y]))
        plt.savefig(SAVE_PATH)
        plt.show()
        '''
        plt.plot(data[idx:idx+71,0],data[idx:idx+71,1])
        plt.savefig(os.path.join(SAVE_PATH,str(cnt2)))
        '''
        y = y+1

        
      