# -*- coding: utf-8 -*-
"""
Created on Mon Aug 21 15:31:59 2023

@author: ianva
"""
import random
import numpy as np
import pandas as pd
import cv2
import os
import matplotlib.pyplot as plt
import matplotlib
from tensorflow import keras #api for tensorflow
from keras.models import Sequential
from keras.optimizers import Adam
from keras.layers import Convolution1D, Dense, MaxPool1D, Dropout
import csv_to_df

CWD = os.path.dirname(os.getcwd())
RAW_DATA_DIR = os.path.join(CWD,'RAW_DATA')
ROI_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Data')
IMG_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Images')
ANNOTATION_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Labels')


def generate_model(ROI_DIR = ROI_DIR, ANNOTATION_DIR = ANNOTATION_DIR, weights = [55,35,10], lr = .0001, epochs = 300, loss = 'kullback_leibler_divergence'):
    data,labels = csv_to_df()
    x_test = []
    x_train = []
    x_val = []
    y_val = []
    y_train = []
    y_test = []
    for i in range(len(data)):
        select = random.choices(list(range(len(weights))), weights = weights)
        if select[0] == 0:
            x_train.append(data[i])
            y_train.append(labels[i])
        elif select[0] == 1:
            x_test.append(data[i])
            y_test.append(labels[i])
        elif select[0] == 2:
            x_val.append(data[i])
            y_val.append(labels[i])
    return([(np.array(x_test), np.array(y_test)),
            (np.array(x_train), np.array(y_train)),
            (np.array(x_val), np.array(y_val))
            ])

    model = Sequential([
         Convolution1D(filters=2, kernel_size=5,  padding = 'same', name='c1d', activation = 'tanh'),
         MaxPool1D(2, name = 'mp1'),
         Convolution1D(filters=4, kernel_size=5,  padding = 'same', name='c1d2', activation = 'tanh'),
         MaxPool1D(2, name = 'mp2'),
         Convolution1D(filters=8, kernel_size=5,  padding = 'same', name='c1d3', activation = 'tanh'),
         MaxPool1D(2, name = 'mp3'),
         Convolution1D(filters=16, kernel_size=5, padding='same', name='c1d4', activation = 'tanh'),
         MaxPool1D(2, name = 'mp4'),
         Convolution1D(filters=32, kernel_size=5, padding='same', name='c1d5', activation = 'tanh'),
         MaxPool1D(2, name = 'mp5'),
         Convolution1D(filters=64, kernel_size=5, padding='same', name='c1d6', activation = 'tanh'),
         MaxPool1D(8, name = 'mp6'),
         Dropout(0.5),
         Dense(3, activation='softmax')
    ])

    model.compile(optimizer = Adam(learning_rate = lr), loss = loss)
    model.fit(x_train[0], y_train[1], 100, epochs = epochs)
    
    evaluate_model(model, x_val, y_val)
    



















