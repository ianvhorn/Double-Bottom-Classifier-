# -*- coding: utf-8 -*-
"""
Created on Wed Aug 16 16:44:09 2023

@author: ianva
"""

import tensorflow as tf
import numpy as np
import pandas as pd
import cv2
import os
import Neural_Net as NN

from tensorflow import keras #api for tensorflow
from keras import layers, models, datasets, Input
from keras import backend as K
from keras.models import Sequential
from keras.optimizers import Adam
from keras.layers import Convolution1D, Dense, Conv1DTranspose





def count_files(DIR_TO_COUNT = os.path.join(os.path.dirname(os.getcwd()),'ToCount')):
    model = keras.models.load_model(r'C:\Users\ianva\ddPCR_DataProcessing\ModelFile.keras')
    CWD = os.path.dirname(os.getcwd())
    TRAINING_DATA_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Data')
    list_of_files = os.listdir(DIR_TO_COUNT)
    num_files = len(list_of_files)
    counts = np.zeros((num_files,1))
    
    for rawFile in list_of_files:
        index = list_of_files.index(rawFile)
        peak_count = 0
        for file in os.listdir(TRAINING_DATA_DIR):
            
            if os.path.basename(rawFile.replace('.csv', '')) in os.path.basename(file):
                path  = os.path.join(TRAINING_DATA_DIR, file)
                
                peak_count += np.argmax(model.predict(NN.read_in(path)))
        counts[index, 0] = peak_count
    
    return_arr = []
    return_arr.append(counts)
    return_arr.append(np.array(list_of_files).T)
    return return_arr


