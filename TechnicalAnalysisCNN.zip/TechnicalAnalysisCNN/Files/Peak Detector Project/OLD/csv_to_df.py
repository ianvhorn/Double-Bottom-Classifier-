# -*- coding: utf-8 -*-
"""
Created on Mon Aug 21 14:16:06 2023

@author: ianva
"""
import random
import numpy as np
import pandas as pd
import cv2
import os
import matplotlib.pyplot as plt
import matplotlib
from tensorflow import keras #api for tensorflow
from keras.models import Sequential
from keras.optimizers import Adam
from keras.layers import Convolution1D, Dense, MaxPool1D, Dropout


CWD = os.path.dirname(os.getcwd())
RAW_DATA_DIR = os.path.join(CWD,'RAW_DATA')
ROI_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Data')
IMG_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Images')
ANNOTATION_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Labels')



def csv_annotations(ROI_DIR = ROI_DIR, ANNOTATION_DIR = ANNOTATION_DIR):
    data = []
    annotations = []
    for file in os.listdir(ROI_DIR):
        df = pd.read_csv(os.path.join(ROI_DIR,file), skiprows=[0])
        if len(df.index) == 256:
            index = os.listdir(ROI_DIR).index(file)
            data.append(pd.DataFrame().to_numpy()[:,1])
            
            for txt in os.listdir(ANNOTATION_DIR):
                if txt.replace('csv', 'txt') == file:
                    with open(os.path.join(ANNOTATION_DIR,txt), 'r') as LabelFile:
                        annotations.append(LabelFile.read())
    data = np.array(data)
    annotations = np.arr(annotations)
    return data, annotations
                
        