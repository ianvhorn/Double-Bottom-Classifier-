# -*- coding: utf-8 -*-
"""
Created on Fri Aug 11 14:04:16 2023

@author: ianva
"""

import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
#Directories


#Region Detection Hyperparameters

def interpolate_csv(file_location, resample_duration = 3, PEAK_SEPERATION_VOLTAGE = 0.1, NEAR_ZERO_THRESHOLD=0.1):
    df = pd.read_csv(file_location, names=['Time', 'Volt'])

    datetime_df = df.copy()

    datetime_df['Time'] = pd.to_datetime(datetime_df['Time'], unit = 's')

    new_range = pd.date_range(datetime_df.Time[0], datetime_df.Time.values[-1], freq = 's')

    resampled_df = datetime_df.set_index('Time').reindex(new_range).interpolate().reset_index()

    rd_string = str(resample_duration) + 'S'

    final_df = resampled_df.set_index('index').resample(rd_string).mean()

    final_df.index = final_df.index.astype('int64')/(1000000000 * resample_duration)

    final_df.index = final_df.index.astype('int64')

    return(final_df)

def find_ROIs(df, input_filename, output_dir,PEAK_SEPERATION_VOLTAGE = 0.1, NEAR_ZERO_THRESHOLD=0.1):
    current_peak = False
    count = 0
    last_near_zero = 0

    for index, point in df.iterrows():
        if point['Volt'] > 1 and not current_peak:
            current_peak = True

            count += 1
            
            read_file = input_filename.replace('.csv', '')
            
            filename = read_file  + "Region" + str(count) + ".csv"

            df[(last_near_zero):(last_near_zero + 256)].to_csv(os.path.join(output_dir, filename))

        elif point['Volt'] < PEAK_SEPERATION_VOLTAGE and current_peak:
            current_peak = False
        elif point['Volt'] < NEAR_ZERO_THRESHOLD:
            last_near_zero = index
    return(count)


