# -*- coding: utf-8 -*-
"""
Created on Mon Aug 21 14:17:45 2023

@author: mrbrady1
"""
import random
import numpy as np
import pandas as pd
import cv2
import os
import matplotlib.pyplot as plt
import matplotlib
from tensorflow import keras #api for tensorflow
from keras.models import Sequential
from keras.optimizers import Adam
from keras.layers import Convolution1D, Dense, MaxPool1D, Dropout
from sklearn import metrics


CWD = os.path.dirname(os.getcwd())
RAW_DATA_DIR = os.path.join(CWD,'RAW_DATA')
ROI_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Data')
IMG_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Images')
ANNOTATION_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Labels')


def plot_inference(save_path, line_df, truth_locations = [], truth_classes = []):

    colors = ['r', 'g', 'b', 'k']
    ax = line_df.plot(x='Time', y='Volt')
    ax.set_ylim([-3, 5])
    for point, classID in zip(truth_locations):
        ax.scatter(point, color = colors[classID])
    
    plt.savefig(save_path)


def csv_annotations(ROI_DIR = ROI_DIR, ANNOTATION_DIR = ANNOTATION_DIR):
    data = []
    annotations = []
    for file in os.listdir(ROI_DIR):
        df = pd.read_csv(os.path.join(ROI_DIR,file), skiprows=[0])
        if len(df.index) == 256:
            data.append(pd.DataFrame().to_numpy()[:,1])
            
            for txt in os.listdir(ANNOTATION_DIR):
                if txt.replace('csv', 'txt') == file:
                    with open(os.path.join(ANNOTATION_DIR,txt), 'r') as LabelFile:
                        annotations.append(LabelFile.read())
    data = np.array(data)
    annotations = np.arr(annotations)
    return data, annotations


def Annotate(ROI_dir, label_dir, image_dir):
    for file in os.listdir(ROI_dir):
        df = pd.read_csv(os.path.join(ROI_dir, file), names=['Time', 'Volt'])
        plot_inference(image_dir, df)

    for image in os.listdir(image_dir):
        peakType = 0
    
        #Checks if coressponding label exists
        label = os.path.join(label_dir, image.replace('.png', '.txt'))
        if not os.path.isfile(label):
            
            #Read in an load the image
            print(os.path.join(image_dir, image))
            img = cv2.imread(os.path.join(image_dir, image))
            
            h, w, l = img.shape
            
            cv2.namedWindow("RAW DATA", cv2.WINDOW_AUTOSIZE)
            #print(w, h)
            w = int(w / 2.5)
            h = int(h / 2.5)
            #print(w, h)
            #img = cv2.resize(img, (w, h))
            
            cv2.imshow("RAW DATA", img)
    
            #Lets the user select the peak type and press "q" to quit
            k = 0
            while(k != ord('q')):
                if k == ord('w'):
                    peakType = 0
                elif k == ord('e'):
                    peakType = 1
                elif k == ord('r'):
                    peakType = 2
                
                k = cv2.waitKey(1) & 0xFF
    
            with open(file, 'w') as writeTo:
                writeTo.write("{}".format(peakType) + "\n")
            cv2.destroyAllWindows()


def find_ROIs(input_file, output_dir, resample_duration = 3, PEAK_SEPERATION_VOLTAGE = 0, NEAR_ZERO_THRESHOLD = 0.1):
    current_peak = False
    count = 0
    last_near_zero = 0
    box_bound = 0

    df = pd.read_csv(input_file, names=['Time', 'Volt'])
    df['Time'] = pd.to_datetime(df['Time'], unit = 's')
    
    new_range = pd.date_range(df.Time[0], df.Time.values[-1], freq = 's')
    resampled_df = df.set_index('Time').reindex(new_range).interpolate().reset_index()

    rd_string = str(resample_duration) + 'S'

    final_df = resampled_df.set_index('index').resample(rd_string).mean()
    final_df.index = final_df.index.astype('int64')/(1000000000 * resample_duration)
    final_df.index = final_df.index.astype('int64')
    
    for index, point in df.iterrows():
        if point['Volt'] > 1 and not current_peak:
            current_peak = True
            count += 1
            
            filename = input_file.replace('.csv', "Region" + str(count) + ".csv")
            
            box_bound = last_near_zero + 256
            df[(last_near_zero):(box_bound)].to_csv(os.path.join(output_dir, filename))
        elif point['Volt'] < PEAK_SEPERATION_VOLTAGE and current_peak and index >= box_bound:
            current_peak = False
        elif point['Volt'] < NEAR_ZERO_THRESHOLD:
            last_near_zero = index
    return(count)






def production_model(model,LIST_ROI):
    peak_count = 0;
    for data in LIST_ROI:
        classification = np.argmax(model.predict(LIST_ROI))
        peak_count += classification
    return peak_count





def evaluate_model(data, labels, model):
    x = data.resaphe(len(data), 256, 1)
    y = keras.utils.to_categorical(labels)

    predictions = model.predict(x)
    
    acc = np.mean(predictions == y)
    m = metrics.classification_report(y, predictions, digits = 3)
    cm = metrics.confusion_matrix(y, predictions)
    
    cm_display = metrics.ConfusionMatrixDisplay(cm, display_labels = ['Noise / Rebound', 'Single Peaks', 'Poly Peaks'])
    
    cm_display.plot()
    plt.show()
    
    return(acc, m)







def generate_model(ROI_DIR = ROI_DIR, ANNOTATION_DIR = ANNOTATION_DIR, weights = [55,35,10], lr = .0001, epochs = 300, loss = 'kullback_leibler_divergence'):
    data,labels = csv_annotations()
    x_test = []
    x_train = []
    x_val = []
    y_val = []
    y_train = []
    y_test = []
    for i in range(len(data)):
        select = random.choices(list(range(len(weights))), weights = weights)
        if select[0] == 0:
            x_train.append(data[i])
            y_train.append(labels[i])
        elif select[0] == 1:
            x_test.append(data[i])
            y_test.append(labels[i])
        elif select[0] == 2:
            x_val.append(data[i])
            y_val.append(labels[i])
    return([(np.array(x_test), np.array(y_test)),
            (np.array(x_train), np.array(y_train)),
            (np.array(x_val), np.array(y_val))
            ])

    model = Sequential([
         Convolution1D(filters=2, kernel_size=5,  padding = 'same', name='c1d', activation = 'tanh'),
         MaxPool1D(2, name = 'mp1'),
         Convolution1D(filters=4, kernel_size=5,  padding = 'same', name='c1d2', activation = 'tanh'),
         MaxPool1D(2, name = 'mp2'),
         Convolution1D(filters=8, kernel_size=5,  padding = 'same', name='c1d3', activation = 'tanh'),
         MaxPool1D(2, name = 'mp3'),
         Convolution1D(filters=16, kernel_size=5, padding='same', name='c1d4', activation = 'tanh'),
         MaxPool1D(2, name = 'mp4'),
         Convolution1D(filters=32, kernel_size=5, padding='same', name='c1d5', activation = 'tanh'),
         MaxPool1D(2, name = 'mp5'),
         Convolution1D(filters=64, kernel_size=5, padding='same', name='c1d6', activation = 'tanh'),
         MaxPool1D(8, name = 'mp6'),
         Dropout(0.5),
         Dense(3, activation='softmax')
    ])

    model.compile(optimizer = Adam(learning_rate = lr), loss = loss)
    model.fit(x_train[0], y_train[1], 100, epochs = epochs)
    
    evaluate_model(model, x_val, y_val)
            
            
        