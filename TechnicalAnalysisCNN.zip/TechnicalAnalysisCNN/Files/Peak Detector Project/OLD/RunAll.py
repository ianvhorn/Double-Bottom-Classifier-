# -*- coding: utf-8 -*-
"""
Created on Wed Aug 16 10:06:55 2023

@author: ianva
"""
import os
import TheFunc as DD

CWD = os.path.dirname(os.getcwd())
RAW_DATA_DIR = os.path.join(CWD,'RAW_DATA')
TRAINING_DATA_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Data')
TRAINING_IMG_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Images')
TRAINING_ANNOTATIONS_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Labels')


choice = "0"
while(choice != "5"):
    print("Train and Evaluate: 0")
    print("Annotate Data: 1")
    print("Detect Regions/Create Images: 2")
    print("Plot Tagging: 3")
    print("Quit: 5")
    choice = input()
    if(choice == "3"):
        DD.plot_figs(RAW_DATA_DIR, TRAINING_DATA_DIR, CWD)
    if(choice == "2"):
        print("Region Detection")
        for files in os.listdir(RAW_DATA_DIR):
            file_dir = os.path.join(RAW_DATA_DIR, files)
            print(file_dir)
            DD.find_ROIs(DD.interpolate_csv(file_dir), files, TRAINING_DATA_DIR)
            
        DD.img_gen(TRAINING_DATA_DIR, TRAINING_IMG_DIR)
    if(choice == "1"):
        print("annotating data")
        DD.open_imgs(TRAINING_IMG_DIR)    
        
    if(choice == "0"):
        print("Training Net")
        
        DD.train_net(DD.read_for_train(TRAINING_ANNOTATIONS_DIR, TRAINING_DATA_DIR)[0])
    
        DD.evaluate_model(TRAINING_DATA_DIR, TRAINING_ANNOTATIONS_DIR)
        
    if(choice == '4'):
        #print('enter path:')
        #path = input()
        A=[]
        A = DD.count_files()
        #print(CountPeak.count_files())
        for index in range(len(A[0])):
           print(A[0][index],A[1][index])
        



