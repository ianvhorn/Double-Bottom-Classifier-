# -*- coding: utf-8 -*-
"""
Created on Mon Aug 14 12:01:51 2023

@author: ianva
"""

import os
import cv2


CWD = os.getcwd() #gets directory code is in
DIR = os.path.dirname(CWD)#gets directory the folder of code is in
ANNOTATIONS_PATH = os.path.join(DIR,'TRAINING_DATA','Labels')
DATA_PATH = os.path.join(DIR,'TRAINING_DATA','Data')
IMAGES_PATH = os.path.join(DIR,'TRAINING_DATA','Images')

for txt in os.listdir(ANNOTATIONS_PATH):
    os.remove(os.path.join(ANNOTATIONS_PATH, txt))
for csv in os.listdir(DATA_PATH):
    os.remove(os.path.join(DATA_PATH, csv))
for img in os.listdir(IMAGES_PATH):
    os.remove(os.path.join(IMAGES_PATH, img))