# -*- coding: utf-8 -*-
"""
Created on Mon Aug 21 15:49:23 2023

@author: ianva
"""

import random
import numpy as np
import pandas as pd
import cv2
import os
import matplotlib.pyplot as plt
import matplotlib
from tensorflow import keras #api for tensorflow
from keras.models import Sequential
from keras.optimizers import Adam
from keras.layers import Convolution1D, Dense, MaxPool1D, Dropout


def production_model(model,LIST_ROI):
    num_files = len(LIST_ROI)
    peak_count = 0;
    for data in LIST_ROI:
        classification = np.argmax(model.predict(LIST_ROI))
        peak_count += classification
    return peak_count