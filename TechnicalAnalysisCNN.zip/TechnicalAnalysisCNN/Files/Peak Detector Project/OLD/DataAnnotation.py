# -*- coding: utf-8 -*-
"""
Created on Fri Aug 11 14:01:37 2023

@author: ianva
"""

"""

press p for peak
press n for noise
press t for triple

press q to quit


peak is 1
noise is 2
triple is 3

"""

#Imports
#!apt update && apt install -y python3-opencv
#!pip install opencv-python
import os
#!pip install opencv-python
import cv2

#Setting up directories
SCRIPT_DIR   = os.getcwd()
#print(SCRIPT_DIR)
ROOT_DIR     = os.path.dirname(SCRIPT_DIR)

#Everything we will be doing in this script should take place within TRAINNING
TRAINNING_DIR = os.path.join(ROOT_DIR, "TRAINING_DATA")

IMAGE_DIR     = os.path.join(TRAINNING_DIR, 'Images')
LABEL_DIR     = os.path.join(TRAINNING_DIR, 'Labels')
    
def peakType_set(key, peakType):
    #Sets mode based on key input
    if key == ord('w'):
        peakType = 0
    elif key == ord('e'):
        peakType = 1
    elif key == ord('r'):
        peakType = 2
    return peakType

#Exports the corrosponding peak type to file
def export_relative(file, peakType):
    with open(file, 'w') as w:
        w.write("{}".format(peakType) + "\n")

#Loops through all images in the given directory
def open_imgs(IMAGE_DIR):
    for image in os.listdir(IMAGE_DIR):
        peakType = 0
        
        #Checks if coressponding label exists
        label = os.path.join(LABEL_DIR, image.replace('.png', '.txt'))
        if not os.path.isfile(label):
        
            #Read in an load the image
            print(os.path.join(IMAGE_DIR, image))
            img = cv2.imread(os.path.join(IMAGE_DIR, image))
        
            h, w, l = img.shape
        
            cv2.namedWindow("RAW DATA", cv2.WINDOW_AUTOSIZE)
        #print(w, h)
            w = int(w / 2.5)
            h = int(h / 2.5)
        #print(w, h)
        #img = cv2.resize(img, (w, h))
        
            cv2.imshow("RAW DATA", img)

        #Lets the user select the peak type and press "q" to quit
            k = 0
            while(k != ord('q')):
                peakType = peakType_set(k, peakType)
            
                k = cv2.waitKey(1) & 0xFF


            export_relative(label, peakType)
            cv2.destroyAllWindows()
            
