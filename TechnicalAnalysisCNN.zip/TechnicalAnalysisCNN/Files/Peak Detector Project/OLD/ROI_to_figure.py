# -*- coding: utf-8 -*-
"""
Created on Fri Aug 11 14:11:08 2023

@author: ianva
"""

import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import matplotlib

matplotlib.use('Agg')
'''
SCRIPT_DIR   = os.getcwd()

TRAINING_DIR = os.path.join(os.path.dirname(SCRIPT_DIR), "TRAINING_DATA")


DATA_DIR     = os.path.join(TRAINING_DIR, 'Data')
IM_DIR     = os.path.join(TRAINING_DIR, 'Images')
'''
plt.ioff()

def img_gen(DATA_DIR,IM_DIR):
    for data in os.listdir(DATA_DIR):
        #Checks if coressponding image exists
        image = os.path.join(IM_DIR, data.replace('.csv', '.png'))
        if not os.path.isfile(image):
            #Read in an load the data
            #print(os.path.join(DATA_DIR, data))
            df = pd.read_csv(os.path.join(DATA_DIR, data))
            #print(df.head)
            
            fig, ax = plt.subplots(1,1)
            ax = plt.plot(df.index, df['Volt'],color = '#000000')
            fig.set_figwidth(1)
            fig.set_figheight(5)
            plt.xlim(-20, 276)
            plt.ylim(-3, 5)
            fig.savefig(os.path.join(IM_DIR,image))
            
            plt.close('all')
