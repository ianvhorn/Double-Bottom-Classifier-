# -*- coding: utf-8 -*-
"""
Created on Wed Aug 16 10:13:10 2023

@author: mrbrady1
"""

import RegionOfInterest as ROI
import matplotlib.pyplot as plt
import matplotlib
import os
import pandas as pd
import numpy as np



def plot_figs(IN_FILE_DIR,OUT_FILE_DIR, CWD):
    figure_dir = os.path.join(CWD, 'FIGURES')
    print(figure_dir)
    #Region Detection Hyperparameters
    RESAMPLE_DURATION = 3#Seconds
    NEAR_ZERO_THRESHOLD = 0.1#V
    PEAK_SEPERATION_VOLTAGE = 0.1#V
    
    def plot_ROIs(raw_file, data_dir):
        raw_file_nosuf = raw_file.replace('.csv', '')
        print('\n\n\n', raw_file_nosuf)
        print(os.path.join(figure_dir, os.path.basename(raw_file_nosuf) + '.png'))
        df = pd.read_csv(raw_file, names=['Time', 'Volt'])
        
        ax = df.plot(x='Time', y='Volt')
        ax.set_ylim([-3, 5])
    
        for files in os.listdir(data_dir):
            if os.path.basename(raw_file_nosuf) in files:
                color = list(np.random.choice(np.linspace(0, 1, 255), size=3))
                df = pd.read_csv(os.path.join(data_dir, files), names=['Time', 'Volt'], dtype={'index': 'Int64', 'Volt': 'float'}, skiprows=[0])
                highest_point = df['Volt'].idxmax()
                print(highest_point)
                ax.scatter(df['Time'].iloc[highest_point] * 3, df['Volt'].iloc[highest_point], color = color)
                ax.axvline(x = df['Time'].iloc[0] * 3, color = color)
                ax.axvline(x = df['Time'].iloc[-1] * 3, color = color)
        plt.savefig(os.path.join(figure_dir, os.path.basename(raw_file_nosuf) + '.png'))
    
    for files in os.listdir(IN_FILE_DIR):
        file_dir = os.path.join(IN_FILE_DIR, files)
        ROI.find_ROIs(ROI.interpolate_csv(file_dir, RESAMPLE_DURATION), files, OUT_FILE_DIR,
                      PEAK_SEPERATION_VOLTAGE, NEAR_ZERO_THRESHOLD)
        plot_ROIs(file_dir, OUT_FILE_DIR)
