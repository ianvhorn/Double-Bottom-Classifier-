# -*- coding: utf-8 -*-
"""
Created on Fri Aug 11 13:57:44 2023

@author: ianva
"""

import tensorflow as tf
import numpy as np
import pandas as pd
import cv2
import os
import random
from tensorflow import keras #api for tensorflow
from keras import layers, models, datasets, Input
from keras import backend as K
from keras.models import Sequential
from keras.optimizers import Adam
from keras.layers import Convolution1D, Dense, Conv1DTranspose


def read_in(ROI_PATH,MAX_FILES=1000,number_classes = 3):
    data = []
    if os.path.isfile(ROI_PATH):
        df = pd.read_csv(ROI_PATH)
        if df.size == 256:
            data = pd.DataFrame().to_numpy()[:,1].T
        else:
            data = np.zeros((256,1))
       
    data = np.array(data).reshape((1, 256, 1))
            
    return data
        

def train_net(ANNOTATIONS_PATH,DATA_PATH,MAX_FILES=1000,epochs=300,number_classes = 3):
    annotations = []
    data = []

    count_peak = 0
    count_rebound = 0
    count_poly = 0
    
    for txt in os.listdir(ANNOTATIONS_PATH):#for every file to analize
        path_csv = os.path.join(DATA_PATH,txt.replace('txt', 'csv'))#create path of corrosponding data file
        path_txt = os.path.join(ANNOTATIONS_PATH,txt)#path of current annotations file
        if os.path.isfile(path_txt):
            labelFile = open(path_txt,'r')#open file containing lable
            classID = int(labelFile.read())
            labelFile.close()
            csv_data = pd.DataFrame(pd.read_csv(path_csv)).to_numpy()[:,1].T
            if classID == 0 and count_peak < MAX_FILES:
                if len(csv_data) == 256:
                    data.append(csv_data)
                    annotations.append(classID)
                    count_peak += 1
            elif classID == 1 and count_rebound < MAX_FILES and number_classes > 1:
                if len(csv_data) == 256:
                    data.append(csv_data)
                    annotations.append(classID)
                    count_rebound += 1
            elif classID == 2 and count_poly < MAX_FILES and number_classes > 2:
                if len(csv_data) == 256:
                    data.append(csv_data)
                    annotations.append(classID)
                    count_poly += 1
            
        else:
            print('Moving', txt)
            os.rename(os.path.join(ANNOTATIONS_PATH, txt), os.path.join(r'C:\Users\ianva\OneDrive\Documents\ddPCR_DataProcessing\ToAdd', txt))
    
    model = Sequential([
         Convolution1D(filters=2, kernel_size=5,  padding = 'same', name='c1d', activation = 'tanh'),
         layers.MaxPool1D(2, name = 'mp1'),
         Convolution1D(filters=4, kernel_size=5,  padding = 'same', name='c1d2', activation = 'relu'),
         layers.MaxPool1D(2, name = 'mp2'),
         Convolution1D(filters=8, kernel_size=5,  padding = 'same', name='c1d3', activation = 'tanh'),
         layers.MaxPool1D(2, name = 'mp3'),
         Convolution1D(filters=16, kernel_size=5, padding='same', name='c1d4', activation = 'tanh'),
         layers.MaxPool1D(2, name = 'mp4'),
         Convolution1D(filters=32, kernel_size=5, padding='same', name='c1d5', activation = 'relu'),
         layers.MaxPool1D(2, name = 'mp5'),
         Convolution1D(filters=64, kernel_size=5, padding='same', name='c1d6', activation = 'tanh'),
         layers.MaxPool1D(8, name = 'mp6'),
         Dense(number_classes,activation='softmax')
    ])
    
    x = np.array(data).reshape((len(data), 256, 1))
    y = keras.utils.to_categorical(annotations, number_classes).reshape((len(data), 1, number_classes))
    x_test = []
    x_train = []
    x_val = []
    y_val = []
    y_train = []
    y_test = []
    
    for i in range(len(data)):
        select = random.choices([0, 1, 2], weights = (60, 40, 0))
        if select[0] == 0:
            x_train.append(x[i])
            y_train.append(y[i])
        elif select[0] == 1:
            x_test.append(x[i])
            y_test.append(y[i])
        elif select[0] == 2:
            x_val.append(x[i])
            y_val.append(y[i])
    
    model.compile(optimizer = Adam(lr=.0001), loss = 'mae')
    
    #model.summary()
    print(np.array(x_train).shape, np.array(y_train).shape)
    model.fit(np.array(x_train), np.array(y_train), 100, epochs = epochs)
    
    model.save(r'C:\Users\ianva\OneDrive\Documents\ddPCR_DataProcessing\TwoChromie.keras')
    
    ground_truths = np.argmax(np.array(y_test), axis = 2)
    predictions = np.argmax(model.predict(np.array(x_test)), axis = 2)
    
    print(np.mean(predictions == ground_truths))
