# -*- coding: utf-8 -*-
"""

press p for peak
press n for noise
press t for triple

press q to quit


peak is 0
noise is 1
triple is 2

"""

#Imports
import os
import cv2
import pandas as pd
from TheFunky2 import plot_inference


def Annotate(ROI_dir, label_dir, image_dir):
    for file in os.listdir(ROI_dir):
        df = pd.read_csv(os.path.join(ROI_dir, file), names=['Time', 'Volt'])
        plot_inference(image_dir, df)

    for image in os.listdir(image_dir):
        peakType = 0
    
        #Checks if coressponding label exists
        label = os.path.join(label_dir, image.replace('.png', '.txt'))
        if not os.path.isfile(label):
            
            #Read in an load the image
            print(os.path.join(image_dir, image))
            img = cv2.imread(os.path.join(image_dir, image))
            
            h, w, l = img.shape
            
            cv2.namedWindow("RAW DATA", cv2.WINDOW_AUTOSIZE)
            #print(w, h)
            w = int(w / 2.5)
            h = int(h / 2.5)
            #print(w, h)
            #img = cv2.resize(img, (w, h))
            
            cv2.imshow("RAW DATA", img)
    
            #Lets the user select the peak type and press "q" to quit
            k = 0
            while(k != ord('q')):
                if k == ord('w'):
                    peakType = 0
                elif k == ord('e'):
                    peakType = 1
                elif k == ord('r'):
                    peakType = 2
                
                k = cv2.waitKey(1) & 0xFF
    
            with open(file, 'w') as writeTo:
                writeTo.write("{}".format(peakType) + "\n")
            cv2.destroyAllWindows()
            
Annotate(r'C:\Users\ianva\ddPCR_DataProcessing\ToCount',r'C:\Users\ianva\ddPCR_DataProcessing\TRAINING_DATA\Labels', r'C:\Users\ianva\ddPCR_DataProcessing\TRAINING_DATA\Images')