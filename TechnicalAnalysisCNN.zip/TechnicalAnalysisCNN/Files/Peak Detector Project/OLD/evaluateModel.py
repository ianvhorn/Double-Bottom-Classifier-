# -*- coding: utf-8 -*-
"""
Created on Mon Aug 14 15:15:48 2023

@author: ianva
"""
import tensorflow as tf
import numpy as np
import pandas as pd
import cv2
import os

from tensorflow import keras #api for tensorflow
from keras import layers, models, datasets, Input
from keras import backend as K
from keras.models import Sequential
from keras.optimizers import Adam
from keras.layers import Convolution1D, Dense, Conv1DTranspose

def evaluate_model(DATA_PATH,ANNOTATIONS_PATH):
    
    FILE_AMT = len(os.listdir(ANNOTATIONS_PATH))
    
    annotations = np.zeros((FILE_AMT,1,1))#creates correct output array of correct length
    data = np.zeros((FILE_AMT, 256 ,1))#creates input array of correct length
    
    
    for txt in os.listdir(ANNOTATIONS_PATH):#for every file to analize
        
        index = os.listdir(ANNOTATIONS_PATH).index(txt)#get the index of the file being run
    
        path_csv = os.path.join(DATA_PATH,txt.replace('txt', 'csv'))#create path of corrosponding data file
        path_txt = os.path.join(ANNOTATIONS_PATH,txt)#path of current annotations file
        if os.path.isfile(path_txt):
            labelFile = open(path_txt,'r')#open file containing lable
            annotations[index,:, 0] = labelFile.read()#add to annotations matrix
            labelFile.close()
            
            dataFile = open(path_csv,'r')#open data file
            
            #  reads data in using pandas, converts data to array, takes the second column and assigns it to
            #  the current column of data
            if len(pd.DataFrame(pd.read_csv(path_csv)).to_numpy()[:,1].T) == 256:
                data[index,:, 0] = pd.DataFrame(pd.read_csv(path_csv)).to_numpy()[:,1].T
            dataFile.close
        else:
            print('Moving', txt)
            os.rename(os.path.join(ANNOTATIONS_PATH, txt), os.path.join(r'C:\Users\ianva\OneDrive\Documents\ddPCR_DataProcessing\ToAdd', txt))
    
    x = data
    y = keras.utils.to_categorical(annotations)
    count = 0
    numIterations = 0
    model = keras.models.load_model(r'C:\Users\ianva\OneDrive\Documents\ddPCR_DataProcessing\ModelFile.keras')
    
    for gt, value in zip(y[:100], x[:100]):
        value = value.reshape(1, 256, 1)
        
        gt_category = np.argmax(gt)
        
        print(gt_category, model.predict(value))
        if gt_category == np.argmax(model.predict(value)):
            count += 1
            numIterations += 1
        else:
            numIterations += 1
            
    print(count / numIterations)
