# -*- coding: utf-8 -*-
"""
Created on Thu Aug 17 14:33:01 2023

@author: mrbrady1
"""
import random
import numpy as np
import pandas as pd
import cv2
import os
import matplotlib.pyplot as plt
import matplotlib
from tensorflow import keras #api for tensorflow
from keras.models import Sequential
from keras.optimizers import Adam
from keras.layers import Convolution1D, Dense, MaxPool1D, Dropout
matplotlib.use('Agg')

def plot_ROIs(raw_file, data_dir, figure_dir, answers, v_line=True):
    raw_file_nosuf = os.path.basename(raw_file).replace('RAW.csv', '')
    #print('\n\n\n', raw_file_nosuf)
    #print(os.path.join(figure_dir, os.path.basename(raw_file_nosuf) + '.png'))
    df = pd.read_csv(raw_file, names=['Time', 'Volt'])
    
    ax = df.plot(x='Time', y='Volt')
    ax.set_ylim([-3, 5])

    for files, classID in zip(os.listdir(data_dir), answers):
        index = os.listdir(data_dir).index(files)
        split_name = os.path.basename(files).split('RAW')[0]
        #print(raw_file_nosuf, split_name)
        if raw_file_nosuf == split_name:
            
            #color = list(np.random.choice(np.linspace(0, 1, 255), size=3))
            color = ['r', 'g', 'b', 'k']
            
            
            
            df = pd.read_csv(os.path.join(data_dir, files), names=['Time', 'Volt'], dtype={'index': 'Int64', 'Volt': 'float'}, skiprows=[0])
            highest_point = df['Volt'].idxmax()
            ax.scatter(df['Time'].iloc[highest_point] * 3, df['Volt'].iloc[highest_point], color = color[int(classID)])
            if v_line:
                ax.axvline(x = df['Time'].iloc[0] * 3, color = color)
                ax.axvline(x = df['Time'].iloc[-1] * 3, color = color)
    plt.savefig(os.path.join(figure_dir, os.path.basename(raw_file_nosuf) + '.png'))

def plot_figs(IN_FILE_DIR, ROI_DIR, answers, figure_dir = os.path.join(os.path.dirname(os.getcwd()),'FIGURES'), v_line=True):

    for files, classes in zip(os.listdir(IN_FILE_DIR), answers):
        file_dir = os.path.join(IN_FILE_DIR, files)
        plot_ROIs(file_dir, ROI_DIR, figure_dir, classes, v_line=v_line)
        
        
def evaluate_model(DATA_PATH,ANNOTATIONS_PATH):
    FILE_AMT = len(os.listdir(ANNOTATIONS_PATH))
    annotations = np.zeros((FILE_AMT,1,1))#creates correct output array of correct length
    data = np.zeros((FILE_AMT, 256 ,1))#creates input array of correct length
    
    for txt in os.listdir(ANNOTATIONS_PATH):#for every file to analize
        
        index = os.listdir(ANNOTATIONS_PATH).index(txt)#get the index of the file being run
    
        path_csv = os.path.join(DATA_PATH,txt.replace('txt', 'csv'))#create path of corrosponding data file
        path_txt = os.path.join(ANNOTATIONS_PATH,txt)#path of current annotations file
        if os.path.isfile(path_txt):
            labelFile = open(path_txt,'r')#open file containing lable
            annotations[index,:, 0] = labelFile.read()#add to annotations matrix
            labelFile.close()
            
            dataFile = open(path_csv,'r')#open data file
            
            #  reads data in using pandas, converts data to array, takes the second column and assigns it to
            #  the current column of data
            if len(pd.DataFrame(pd.read_csv(path_csv)).to_numpy()[:,1].T) == 256:
                data[index,:, 0] = pd.DataFrame(pd.read_csv(path_csv)).to_numpy()[:,1].T
            dataFile.close
        else:
            print('Moving', txt)
            os.rename(os.path.join(ANNOTATIONS_PATH, txt), os.path.join(r'C:\Users\ianva\OneDrive\Documents\ddPCR_DataProcessing\ToAdd', txt))
    
    x = data
    y = keras.utils.to_categorical(annotations)
    count = 0
    numIterations = 0
    model = keras.models.load_model(r'C:\Users\ianva\ddPCR_DataProcessing\ModelFile.keras')
    
    for gt, value in zip(y[:100], x[:100]):
        value = value.reshape(1, 256, 1)
        gt_category = np.argmax(gt)
        if gt_category == np.argmax(model.predict(value)):
            count += 1
            numIterations += 1
        else:
            numIterations += 1
    print(count / numIterations)
    
    
def peakType_set(key, peakType):
    #Sets mode based on key input
    if key == ord('w'):
        peakType = 0
    elif key == ord('e'):
        peakType = 1
    elif key == ord('r'):
        peakType = 2
    return peakType

#Exports the corrosponding peak type to file
def export_relative(file, peakType):
    with open(file, 'w') as w:
        w.write("{}".format(peakType) + "\n")

def open_imgs(IMAGE_DIR, LABEL_DIR):
    print('w = 0 = rebound')
    print('e = 1 = peak')
    print('r = 2 = poly peaks')
    for image in os.listdir(IMAGE_DIR):
        peakType = 0
        label = os.path.join(LABEL_DIR, image.replace('.png', '.txt'))
        if not os.path.isfile(label):
            img = cv2.imread(os.path.join(IMAGE_DIR, image))
            
            cv2.namedWindow("RAW DATA", cv2.WINDOW_AUTOSIZE)
            h, w, l = img.shape
            w = int(w / 2.5)
            h = int(h / 2.5)

            cv2.imshow("RAW DATA", img)
            k = 0
            while(k != ord('q')):
                peakType = peakType_set(k, peakType)
                k = cv2.waitKey(1) & 0xFF
            export_relative(label, peakType)
            cv2.destroyAllWindows()

def interpolate_csv(file_location, resample_duration = 3):
    df = pd.read_csv(file_location, names=['Time', 'Volt'])

    datetime_df = df.copy()
    
    datetime_df['Time'] = pd.to_datetime(datetime_df['Time'], unit = 's')

    new_range = pd.date_range(datetime_df.Time[0], datetime_df.Time.values[-1], freq = 's')

    resampled_df = datetime_df.set_index('Time').reindex(new_range).interpolate().reset_index()

    rd_string = str(resample_duration) + 'S'

    final_df = resampled_df.set_index('index').resample(rd_string).mean()

    final_df.index = final_df.index.astype('int64')/(1000000000 * resample_duration)

    final_df.index = final_df.index.astype('int64')

    return(final_df)

def find_ROIs(df, input_filename, output_dir, PEAK_SEPERATION_VOLTAGE = 0, NEAR_ZERO_THRESHOLD = 0.1):
    current_peak = False
    count = 0
    last_near_zero = 0
    box_bound = 0
    
    for index, point in df.iterrows():
        if point['Volt'] > 1 and not current_peak:
            current_peak = True

            count += 1
            
            read_file = input_filename.replace('.csv', '')
            
            filename = read_file  + "Region" + str(count) + ".csv"

            df[(last_near_zero):(last_near_zero + 256)].to_csv(os.path.join(output_dir, filename))
            box_bound = last_near_zero + 256
        elif point['Volt'] < PEAK_SEPERATION_VOLTAGE and current_peak and index >= box_bound:
            current_peak = False
        elif point['Volt'] < NEAR_ZERO_THRESHOLD:
            last_near_zero = index
    return(count)

def img_gen(DATA_DIR,IM_DIR):
    for data in os.listdir(DATA_DIR):
        #Checks if coressponding image exists
        image = os.path.join(IM_DIR, data.replace('.csv', '.png'))
        if not os.path.isfile(image):
            #Read in an load the data
            #print(os.path.join(DATA_DIR, data))
            df = pd.read_csv(os.path.join(DATA_DIR, data))
            #print(df.head)
            
            fig, ax = plt.subplots(1,1)
            ax = plt.plot(df.index, df['Volt'],color = '#000000')
            fig.set_figwidth(1)
            fig.set_figheight(5)
            plt.xlim(-20, 276)
            plt.ylim(-3, 5)
            fig.savefig(os.path.join(IM_DIR,image))
            
            plt.close('all')

def split_data(data, labels, weights):
    x_test = []
    x_train = []
    x_val = []
    y_val = []
    y_train = []
    y_test = []
    for i in range(len(data)):
        select = random.choices(list(range(len(weights))), weights = weights)
        if select[0] == 0:
            x_train.append(data[i])
            y_train.append(labels[i])
        elif select[0] == 1:
            x_test.append(data[i])
            y_test.append(labels[i])
        elif select[0] == 2:
            x_val.append(data[i])
            y_val.append(labels[i])
    return([(np.array(x_test), np.array(y_test)),
            (np.array(x_train), np.array(y_train)),
            (np.array(x_val), np.array(y_val))
            ])
def read_for_train(ANNOTATIONS_PATH,DATA_PATH,train_test_val_weights = (60,40,0)):
    annotations = []
    data = []
    for txt in os.listdir(ANNOTATIONS_PATH):#for every file to analize
        path_csv = os.path.join(DATA_PATH,txt.replace('txt', 'csv'))#create path of corrosponding data file
        path_txt = os.path.join(ANNOTATIONS_PATH,txt)#path of current annotations file
        if os.path.isfile(path_txt):
            labelFile = open(path_txt,'r')#open file containing lable
            classID = int(labelFile.read())
            labelFile.close()
            csv_data = pd.DataFrame(pd.read_csv(path_csv)).to_numpy()[:,1].T
            if len(csv_data) == 256:
                data.append(csv_data)
                annotations.append(classID)
           
    x = np.array(data).reshape((len(data), 256, 1))
    y = keras.utils.to_categorical(annotations, 3).reshape((len(data), 1, 3))

    train, test, val = split_data(x, y, train_test_val_weights)
    return(train, test, val)


def train_net(train, lr = .0001, loss = 'kullback_leibler_divergence', epochs = 300):
    model = Sequential([
         Convolution1D(filters=2, kernel_size=5,  padding = 'same', name='c1d', activation = 'tanh'),
         MaxPool1D(2, name = 'mp1'),
         Convolution1D(filters=4, kernel_size=5,  padding = 'same', name='c1d2', activation = 'tanh'),
         MaxPool1D(2, name = 'mp2'),
         Convolution1D(filters=8, kernel_size=5,  padding = 'same', name='c1d3', activation = 'tanh'),
         MaxPool1D(2, name = 'mp3'),
         Convolution1D(filters=16, kernel_size=5, padding='same', name='c1d4', activation = 'tanh'),
         MaxPool1D(2, name = 'mp4'),
         Convolution1D(filters=32, kernel_size=5, padding='same', name='c1d5', activation = 'tanh'),
         MaxPool1D(2, name = 'mp5'),
         Convolution1D(filters=64, kernel_size=5, padding='same', name='c1d6', activation = 'tanh'),
         MaxPool1D(8, name = 'mp6'),
         Dropout(0.5),
         Dense(3, activation='softmax')
    ])

    model.compile(optimizer = Adam(learning_rate = lr), loss = loss)
    model.fit(train[0], train[1], 100, epochs = epochs)
    
    return(model)



def read_in(ROI_PATH,MAX_FILES=1000,number_classes = 3):
    data = []
    if os.path.isfile(ROI_PATH):
        df = pd.read_csv(ROI_PATH)
        if df.size == 256:
            data = pd.DataFrame().to_numpy()[:,1].T
        else:
            data = np.zeros((256,1))
       
    data = np.array(data).reshape((1, 256, 1))
            
    return data

def count_files(DIR_TO_COUNT = os.path.join(os.path.dirname(os.getcwd()),'ToCount')):
    model = keras.models.load_model(r'C:\Users\ianva\ddPCR_DataProcessing\ModelFile.keras')
    CWD = os.path.dirname(os.getcwd())
    TRAINING_DATA_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Data')
    list_of_files = os.listdir(DIR_TO_COUNT)
    num_files = len(list_of_files)
    counts = np.zeros(num_files)
    
    for rawFile in list_of_files:
        print(rawFile)

        file_with_path = os.path.join(DIR_TO_COUNT, rawFile)
        
        df = interpolate_csv(file_with_path)
        
        find_ROIs(df, rawFile, TRAINING_DATA_DIR)
        
        index = list_of_files.index(rawFile)
        peak_count = 0
        predictions = []
        all_predictions = []
        for file in os.listdir(TRAINING_DATA_DIR):
            search_substring = os.path.basename(rawFile.replace('RAW.csv', ''))
            
            split_name = os.path.basename(file).split('RAW')[0]
            
            if search_substring == split_name:
                path  = os.path.join(TRAINING_DATA_DIR, file)
                
                classification = np.argmax(model.predict(read_in(path)))
                
                peak_count += classification
                
                predictions.append(classification)
        counts[index] = peak_count
        all_predictions.append(predictions)
    return_arr = []
    return_arr.append(counts)
    return_arr.append(np.array(list_of_files).T)
    
    df = pd.read_excel(r'C:\Users\ianva\ddPCR_DataProcessing\Counts\Data Collection - 10um.xlsx')
    
    file_names = pd.DataFrame(df).to_numpy()[:,0]#read in names from file
    
    orderedCounts = np.zeros(len(file_names))
    
    for file in file_names:#for every file name in the csv of counts
        index = np.where(file_names==file)[0]#get the index of that file

        for fileA in list_of_files: #for every file in the to count filder
            indexA = list_of_files.index(fileA)#get index of this file
            
            if fileA.replace('RAW.csv','') == file: #find the file name that matches the one in the csv
               
                orderedCounts[index] = counts[indexA]#assign the ordered count list the
                                                     #count that matches current file
                
                
    df ['NN']= pd.Series(orderedCounts) 
    
    df.to_excel(r'C:\Users\ianva\ddPCR_DataProcessing\Counts\Data Collection - 10um.xlsx', index = False)
    
    
    plot_figs(DIR_TO_COUNT,TRAINING_DATA_DIR, answers = all_predictions, v_line=False)
    return return_arr


