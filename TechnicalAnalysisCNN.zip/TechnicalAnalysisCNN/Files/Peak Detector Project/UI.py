# -*- coding: utf-8 -*-
"""
Created on Tue Aug 22 09:25:34 2023

@author: ianva
"""

import functions as fn
import random
import numpy as np
import pandas as pd
import cv2
import os
import matplotlib.pyplot as plt
from tensorflow import keras #api for tensorflow
from keras.models import Sequential
from keras.optimizers import Adam
from keras.layers import Convolution1D, Dense, MaxPool1D, Dropout
from sklearn import metrics

CWD = os.path.dirname(os.getcwd())
COUNTS_DIR = os.path.join(CWD, 'Counts')
RAW_DATA_DIR = os.path.join(CWD,'RAW_DATA')
ROI_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Data')
IMG_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Images')
ANNOTATION_DIR = os.path.join(CWD, 'TRAINING_DATA', 'Labels')
FIGURES_DIR = os.path.join(CWD,'FIGURES')

def count_all(COUNT_DIR = RAW_DATA_DIR, ROI_DIR = ROI_DIR):
    #define list of ROI's and counts
    
    COUNTS = []
    
    #Loops through raw data, file is a raw data file
    for file in os.listdir(COUNT_DIR):
        ROIs = []
        #Loops through RIO folder, file1 is a ROI csv
        for file1 in os.listdir(ROI_DIR):
            #checks if a region of intrest was generated from the current raw file
            if (file1.split('Region')[0] == file.replace('.csv','')):
                #if it is add that set of data to the ROIs list
                ROIs.append(pd.DataFrame(pd.read_csv(os.path.join(ROI_DIR,file1))).to_numpy()[:,1])
        #convert list to 3D numpy array, thatis the format the NN accepts     
        if len(ROIs) > 0:
            ROI_arr = np.zeros((len(ROIs),64,1))
            ROI_arr = np.array(ROIs)
            
            #Add the count of the raw file to the counts lust
            
            COUNTS.append(fn.production_model(ROI_arr))
        else:
            COUNTS.append(0)
    return os.listdir(COUNT_DIR),COUNTS


def write_counts(LIST_RAWNAMES,LIST_COUNTS,OUT_FILE = os.path.join(COUNTS_DIR, r'Data Collection - 10um.xlsx')):
    #read the counts file in and store it
    df = pd.read_excel(OUT_FILE)
    
    #read in names from file
    file_names = pd.DataFrame(df).to_numpy()[:,0]
    orderedCounts = np.zeros(len(file_names))
           
    for file in file_names:#for every file name in the csv of counts
        index = np.where(file_names==file)[0]#get the index of that file

        for fileA in LIST_RAWNAMES: #for every file in the to count filder
            indexA = LIST_RAWNAMES.index(fileA)#get index of this file
            
            if fileA.replace('RAW.csv','') == file: #find the file name that matches the one in the csv
               orderedCounts[index] = LIST_COUNTS[indexA]#assign the ordered count list the
                                             #count that matches current file
                
    df ['NN']= pd.Series(orderedCounts) 
    
    df.to_excel(OUT_FILE, index = False)
    
    
def create_allROIs(RAW_DATA_DIR=RAW_DATA_DIR, ROI_DIR=ROI_DIR):
    
    for file in os.listdir(RAW_DATA_DIR):
        #print(os.path.join(RAW_DATA_DIR,file))
        fn.find_ROIs(os.path.join(RAW_DATA_DIR,file), ROI_DIR)


create_allROIs()
r'''
names = []
data = []

names,data = count_all()
print('Files Counted')
write_counts(names, data)
print('Generating Plots')




for file in os.listdir(RAW_DATA_DIR):#loop all raw data, file is current raw data file
    model = r"C:\Users\ianva\ddPCR_DataProcessing\modelFile.keras"
    model = keras.models.load_model(model)#load model
    plot_locations = []
    plot_classes = []
    vline = []
    for fileD in os.listdir(ROI_DIR):#check each RIO
        #print(fileD.split('Region')[0],file.replace('.csv','') )
        if fileD.split('Region')[0] == file.replace('.csv',''):#if the ROI goes with the RAW

        
        
            df = pd.read_csv(os.path.join(ROI_DIR,fileD),names = ['Time','volts'],skiprows=[0])
            index = df[['volts']].idxmax()
            vline.append((df['Time'].iloc[0] * 10, df['Time'].iloc[-1] * 10))
            plot_locations.append((df['Time'].iloc[index] * 10,df['volts'].iloc[index] * 10))
            
            ROI_LIST = [pd.DataFrame(df).to_numpy()[:,1].reshape((1,64,1))]
            
            plot_classes.append(np.argmax(model.predict(ROI_LIST)))

                             
                             
    rawDF = pd.read_csv(os.path.join(RAW_DATA_DIR,file), names = ['Time', 'Volt'])
    save_path = os.path.join(FIGURES_DIR, file.replace('.csv', '.png'))
    #print(save_path)
    #print(plot_locations)
    fn.plot_inference(save_path,rawDF,plot_locations, plot_classes, vline)

    '''
    
    
    
    
    
    