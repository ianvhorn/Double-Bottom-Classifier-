# -*- coding: utf-8 -*-
"""
Created on Fri Apr  5 15:55:40 2024

@author: ianva
"""

import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt
import cv2
import matplotlib.pyplot as plt
from tensorflow import keras #api for tensorflow
from keras.models import Sequential
from keras.optimizers import Adam
from keras.layers import Convolution1D, Dense, MaxPool1D, Dropout, BatchNormalization
from sklearn import metrics


CWD = os.path.dirname(os.getcwd())
SAVE_PATH = os.path.join(CWD, 'DBimages')
SAVE_PATH_CHECK = os.path.join(CWD, 'Predictions')
SAVE_PATH2 = os.path.join(CWD, 'LOOK_TAG')
TRU_DIR = os.path.join(CWD, r'DB_sections')
TRU_PATH = os.path.join(CWD, r'DB_sections\SPY_TRU.csv')

def production_model(model = r"C:\Users\ianva\TechnicalAnalysisCNN\Models\BEST-large\savedModel.keras" ):
    model = keras.models.load_model(model)#load model
    
    
    print("PASS")
    df = pd.read_csv(os.path.join(CWD,"TEST.csv"), skiprows=[0],usecols=[2], header = None)
    end = 0
    while end < df.shape[0]:
        start = end
        end = start+15
        roi = np.array(df.iloc[start:end])
        roi = roi-roi.min()
        roi = roi/roi.max()
        data = roi.reshape((1,15,1))
        print(np.argmax(model.predict(data)))
        print(model.predict(data))
        print(data)
        classification = np.round(model.predict(data))
        
        if classification != 3:          
            plt.figure(figsize=(15,6))# make the figure wider to more easily see data
            
            # Get rid of padding on x axis (this makes it easier to go from pixels to data values)
            ax = plt.gca();
            ax.set_xlim(0.0, (15)-1);
    
            #Create the plot and save is as a unique image
            plt.plot(range(0,15),roi) 
            num = end//15
            temp_path = os.path.join(SAVE_PATH_CHECK,str(num))
            plt.savefig(temp_path) # Save the matplot plot as a png
            
            # set up some info about the image size
            img = cv2.imread(os.path.join(temp_path+".png"))#Read in the png of the matplot graph
            imgHeight = img.shape[0]
            graphLength = (img.shape[1]-(img.shape[1]-972) - 135) #the length, in pixels, of the x axis
            imgLength = graphLength # 1/3 of the graph, the first and last third are not recorded

            cv2.putText(img,str(start) + "   CLASS: " + str(classification),fontFace=cv2.FONT_HERSHEY_COMPLEX,fontScale=.5,
                    org=(10,30),color = (0,0,0),thickness=1)
            if classification == 1:
                cv2.imwrite(os.path.join(r"C:\Users\ianva\TechnicalAnalysisCNN\Predictions\DB",str(num)+'.png'),img)
            else:
                cv2.imwrite(os.path.join(r"C:\Users\ianva\TechnicalAnalysisCNN\Predictions\BACKROUND",str(num)+'.png'),img)
                


production_model()