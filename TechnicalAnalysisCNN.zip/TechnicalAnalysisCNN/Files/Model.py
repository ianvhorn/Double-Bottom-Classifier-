# -*- coding: utf-8 -*-
"""
Created on Wed Apr  3 21:23:31 2024

@author: ianva
"""
import numpy as np
import pandas as pd
import random
import os
import matplotlib.pyplot as plt
import cv2
from tensorflow import keras #api for tensorflow
from keras.models import Sequential
from keras.optimizers import Adam
from keras.layers import Convolution1D, Dense, MaxPool1D, Dropout, BatchNormalization
from sklearn import metrics



CWD = os.path.dirname(os.getcwd())
SAVE_PATH = os.path.join(CWD, 'DBimages')
TRU_DIR = os.path.join(CWD, r'DB_sections')
TRU_PATH = os.path.join(CWD, r'DB_sections\SPY_TRU.csv')
TRAIN_PATH = os.path.join(CWD, "TRAIN")
DATA = os.path.join(CWD,"RAW_DATA")

def csv_annotations(TRAIN_PATH = TRAIN_PATH):
    
    annotations_df = pd.read_csv(r"C:\Users\ianva\TechnicalAnalysisCNN\TRAIN\SPY_TRU.csv", usecols = [0,1,4],skiprows=[0], header = None)
    data_df = pd.read_csv(os.path.join(DATA,"ALL_DATA.csv"),usecols=[2],skiprows=[0])
    x_test = []
    x_train = []
    x_val = []
    y_val = []
    y_train = []
    y_test = []
    
    x_all = []
    y_all = []
    #print(data_df.head())
    print("SHAPE")
    print(annotations_df.shape[0])
    for index in range(annotations_df.shape[0]):
        start,end = annotations_df.iloc[index,[0,1]] # X is the datavalue y is the truth
        x = data_df.iloc[start:end,0]
        x = (x-x.min())
        x = x/x.max()
        x_all.append(x)
        #y_all.append(y)
        
        

    x_arr = np.array(x_all)
    y = np.array(annotations_df.iloc[:,2])
    print("SHAPE OF GT")
    print(type(y[50]))
    '''
    yn = []
    count = 0
    while count < y.size:
        if y[count] == 1:
            yn.append([0,1])
        else:
            yn.append([1,0])
        count+=1
    '''
    return x_arr,y
    

def evaluate_model(data, labels, model):
    x = data.reshape(len(data), 15, 1)
    y = np.array(labels).squeeze()

    #predictions = np.argmax(np.array(model.predict(x)), axis = 2)
   # print(predictions)
    predictions = np.round(model.predict(x))
    print(predictions)
    acc = np.mean(predictions == y)
    print(acc)
    m = metrics.classification_report(y, predictions, digits = 2)
    cm = metrics.confusion_matrix(y, predictions, normalize = 'true')
    print(cm)
    cm_display = metrics.ConfusionMatrixDisplay(cm, display_labels = ['Noise / Rebound', 'Single Peaks'])
    
    cm_display.plot()
    plt.show()
    
    return(acc, m)


def generate_model(weights = [90,0,10], lr = .0001, epochs = 200, loss ='binary_crossentropy' ): #'kullback_leibler_divergence'
    data,labels = csv_annotations()
    x_test = []
    x_train = []
    x_val = []
    y_val = []
    y_train = []
    y_test = []
    
    for i in range(len(data)):
        select = random.choices(list(range(len(weights))), weights = weights)
        
        if select[0] == 0:
            
            x_train.append(np.float_(data[i]))
            y_train.append(np.int_(labels[i]))
            
            
        elif select[0] == 1:
            x_test.append(np.float_(data[i]))
            y_test.append(np.int_(labels[i]))
        elif select[0] == 2:
            x_val.append(np.float_(data[i]))
            y_val.append(np.int_(labels[i]))
            
            
    model = Sequential([
         Convolution1D(filters=2, kernel_size=5,  padding = 'same', name='c1d', activation = 'tanh'),
         MaxPool1D(2, name = 'mp1'),
         BatchNormalization(),
         Convolution1D(filters=4, kernel_size=5,  padding = 'same', name='c1d2', activation = 'tanh'),
         MaxPool1D(2, name = 'mp2'),
         BatchNormalization(),
         Convolution1D(filters=8, kernel_size=5,  padding = 'same', name='c1d3', activation = 'tanh'),
         MaxPool1D(2, name = 'mp3'),
         BatchNormalization(),
         Convolution1D(filters=16, kernel_size=5, padding='same', name='c1d4', activation = 'tanh'),
        # MaxPool1D(2, name = 'mp4'),
         BatchNormalization(),
         Convolution1D(filters=32, kernel_size=5, padding='same', name='c1d5', activation = 'tanh'),
         #MaxPool1D(1, name = 'mp5'),
         BatchNormalization(),
         Convolution1D(filters=64, kernel_size=5, padding='same', name='c1d6', activation = 'tanh'),
         #MaxPool1D(1, name = 'mp6'),
         Dropout(0.5),
         BatchNormalization(),
         Dense(1, activation='sigmoid')
    ])
    
    data_length = len(x_train)
    x_train = np.array(x_train).reshape(data_length, 15, 1)
    y_train = np.array(y_train).reshape(data_length, 1, 1)
    '''
    print(type(y_train[50]))
    plt.plot((x_train[50]))
    plt.xlabel(str(y_train[50]), fontsize = 15)
    plt.show
    '''
    
    model.compile(optimizer = Adam(learning_rate = lr), loss = loss)
    model.fit(x_train, y_train,200, epochs = epochs)
    model.summary()
    print("FINISHED TRAIN")
    path = os.path.join(CWD,"savedModel.keras")
    model.save(path)
    evaluate_model(np.array(x_val), np.array(y_val), model)
   
    

generate_model()
'''
data, labels = csv_annotations()
print((labels[1]))
print("----------------------")
print(str(data[1]))
'''